<?php

return [
    'catalog' => [
        'products' => [
            'index' => [
                'generate-pdf-btn' => 'उत्पाद PDF बनाएं',
                'sku' => 'SKU',
                'price' => 'मूल्य',
                'product-pdf' => 'उत्पाद PDF',
                'product-list' => 'उत्पाद सूची',
            ],
        ],
    ],
];

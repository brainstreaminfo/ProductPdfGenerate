<?php

return [
    'catalog' => [
        'products' => [
            'index' => [
                'generate-pdf-btn' => 'Gerar PDF dos Produtos',
                'sku' => 'SKU',
                'price' => 'Preço',
                'product-pdf' => 'PDF do Produto',
                'product-list' => 'Lista de Produtos',
            ],
        ],
    ],
];














<?php

return [
    'catalog' => [
        'products' => [
            'index' => [
                'generate-pdf-btn' => 'Создать PDF продуктов',
                'sku' => 'Артикул (SKU)',
                'price' => 'Цена',
                'product-pdf' => 'PDF продукта',
                'product-list' => 'Список продуктов',
            ],
        ],
    ],
];















<?php

return [
    'catalog' => [
        'products' => [
            'index' => [
                'generate-pdf-btn' => 'නිෂ්පාදන PDF ජනනය කරන්න',
                'sku' => 'SKU',
                'price' => 'මිල',
                'product-pdf' => 'නිෂ්පාදන PDF',
                'product-list' => 'නිෂ්පාදන ලැයිස්තුව',
            ],
        ],
    ],
];
















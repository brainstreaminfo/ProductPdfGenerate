<?php

return [
    'catalog' => [
        'products' => [
            'index' => [
                'generate-pdf-btn' => 'Genereer Producten PDF',
                'sku' => 'SKU',
                'price' => 'Prijs',
                'product-pdf' => 'Product PDF',
                'product-list' => 'Productlijst',
            ],
        ],
    ],
];












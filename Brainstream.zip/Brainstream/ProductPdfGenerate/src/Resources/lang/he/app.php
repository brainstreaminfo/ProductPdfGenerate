<?php

return [
    'catalog' => [
        'products' => [
            'index' => [
                'generate-pdf-btn' => 'צור PDF של מוצרים',
                'sku' => 'מק"ט (SKU)',
                'price' => 'מחיר',
                'product-pdf' => 'PDF של מוצר',
                'product-list' => 'רשימת מוצרים',
            ],
        ],
    ],
];

<?php

return [
    'catalog' => [
        'products' => [
            'index' => [
                'generate-pdf-btn' => 'Generate Products PDF',
                'sku' => 'SKU',
                'price' => 'Price',
                'product-pdf' => 'Product PDF',
                'product-list' => 'Product List',
            ],
        ],
    ],
];

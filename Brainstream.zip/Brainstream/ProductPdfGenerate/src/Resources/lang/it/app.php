
<?php

return [
    'catalog' => [
        'products' => [
            'index' => [
                'generate-pdf-btn' => 'Genera PDF dei prodotti',
                'sku' => 'Codice prodotto (SKU)',
                'price' => 'Prezzo',
                'product-pdf' => 'PDF del prodotto',
                'product-list' => 'Elenco prodotti',
            ],
        ],
    ],
];

<?php

return [
    'catalog' => [
        'products' => [
            'index' => [
                'generate-pdf-btn' => 'Generar PDF de productos',
                'sku' => 'SKU',
                'price' => 'Precio',
                'product-pdf' => 'PDF de productos',
                'product-list' => 'Lista de productos',
            ],
        ],
    ],
];

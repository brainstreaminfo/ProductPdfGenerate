<?php

return [
    'catalog' => [
        'products' => [
            'index' => [
                'generate-pdf-btn' => 'Generuj PDF Produktów',
                'sku' => 'SKU',
                'price' => 'Cena',
                'product-pdf' => 'PDF Produktu',
                'product-list' => 'Lista Produktów',
            ],
        ],
    ],
];













<?php

return [
    'catalog' => [
        'products' => [
            'index' => [
                'generate-pdf-btn' => 'Générer le PDF des produits',
                'sku' => 'Référence (SKU)',
                'price' => 'Prix',
                'product-pdf' => 'PDF du produit',
                'product-list' => 'Liste des produits',
            ],
        ],
    ],
];

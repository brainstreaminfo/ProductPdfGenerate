<?php

return [
    'catalog' => [
        'products' => [
            'index' => [
                'generate-pdf-btn' => 'পণ্য PDF তৈরি করুন',
                'sku' => 'এসকেইউ',
                'price' => 'মূল্য',
                'product-pdf' => 'পণ্য PDF',
                'product-list' => 'পণ্যের তালিকা',
            ],
        ],
    ],
];

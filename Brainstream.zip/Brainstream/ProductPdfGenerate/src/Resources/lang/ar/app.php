<?php

return [
    'catalog' => [
        'products' => [
            'index' => [
                'generate-pdf-btn' => 'إنشاء ملف PDF للمنتجات',
                'sku' => 'رمز المنتج',
                'price' => 'السعر',
                'product-pdf' => 'ملف PDF للمنتج',
                'product-list' => 'قائمة المنتجات',
            ],
        ],
    ],
];

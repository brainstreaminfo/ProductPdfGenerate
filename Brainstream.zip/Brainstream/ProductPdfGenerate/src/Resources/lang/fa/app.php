<?php

return [
    'catalog' => [
        'products' => [
            'index' => [
                'generate-pdf-btn' => 'تولید PDF محصولات',
                'sku' => 'کد محصول (SKU)',
                'price' => 'قیمت',
                'product-pdf' => 'PDF محصول',
                'product-list' => 'لیست محصولات',
            ],
        ],
    ],
];

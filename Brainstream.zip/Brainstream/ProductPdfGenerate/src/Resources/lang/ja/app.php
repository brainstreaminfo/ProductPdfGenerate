<?php 

return [
    'catalog' => [
        'products' => [
            'index' => [
                'generate-pdf-btn' => '製品PDFを生成',
                'sku' => 'SKU',
                'price' => '価格',
                'product-pdf' => '製品PDF',
                'product-list' => '製品リスト',
            ],
        ],
    ],
];

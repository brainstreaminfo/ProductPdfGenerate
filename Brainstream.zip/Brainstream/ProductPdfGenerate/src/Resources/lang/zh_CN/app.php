<?php

return [
    'catalog' => [
        'products' => [
            'index' => [
                'generate-pdf-btn' => '生成产品 PDF',
                'sku' => 'SKU',
                'price' => '价格',
                'product-pdf' => '产品 PDF',
                'product-list' => '产品列表',
            ],
        ],
    ],
];



















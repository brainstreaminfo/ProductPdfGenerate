<?php

return [
    'catalog' => [
        'products' => [
            'index' => [
                'generate-pdf-btn' => 'Produkte PDF erstellen',
                'sku' => 'Artikelnummer (SKU)',
                'price' => 'Preis',
                'product-pdf' => 'Produkt-PDF',
                'product-list' => 'Produktliste',
            ],
        ],
    ],
];

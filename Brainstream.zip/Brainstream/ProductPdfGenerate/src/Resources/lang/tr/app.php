<?php

return [
    'catalog' => [
        'products' => [
            'index' => [
                'generate-pdf-btn' => 'Ürünler PDF\'i Oluştur',
                'sku' => 'SKU',
                'price' => 'Fiyat',
                'product-pdf' => 'Ürün PDF\'i',
                'product-list' => 'Ürün Listesi',
            ],
        ],
    ],
];
















